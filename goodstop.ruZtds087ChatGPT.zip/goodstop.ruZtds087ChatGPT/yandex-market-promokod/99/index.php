<?php
$code1 = $code2 = $code3 = '';
include $_SERVER['DOCUMENT_ROOT'].'/api.php';
if(!empty($z_out)){
  $ex = explode(';;', $z_out);
  $code1 = $ex[0];
  $code2 = $ex[1];
  $code3 = $ex[2];
  $code4 = $ex[3];
  $code5 = $ex[4];
  $code6 = $ex[5];
  $code7 = $ex[6];
  $code8 = $ex[7]; 
  $code9 = $ex[8];
  $code10 = $ex[9];
  $code11 = $ex[10];
  $code12 = $ex[11];
  $code13 = $ex[12];
  $code14 = $ex[13];
  $code15 = $ex[14];
  $code16 = $ex[15];
  $code17 = $ex[16];
}
?>

<!DOCTYPE html>
<html dir="ltr" lang="ru-RU" prefix="og: https://ogp.me/ns#" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="icon" type="image/x-icon" href="[SITE]/favicon.ico">
    <title>[TITLE]</title>
    <script type="text/javascript">
        var bepassive_plugin_bpsr_js = {"nonce":"460a9fa279","grs":false,"ajaxurl":"\/promokod-ajax","func":"bpsr_ajax","msg":"\u041e\u0446\u0435\u043d\u0438\u0442\u0435 \u044d\u0442\u043e\u0442 \u043f\u043e\u0441\u0442","suffix_votes":"s","fuelspeed":400,"thankyou":"\u0421\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u0432\u0430\u0448 \u0433\u043e\u043b\u043e\u0441","error_msg":"An error occurred","tooltip":"0","tooltips":[{"tip":"Poor","color":"red"},{"tip":"Fair","color":"brown"},{"tip":"Average","color":"orange"},{"tip":"Good","color":"blue"},{"tip":"Excellent","color":"green"}]};
    </script>

    <!-- All in One SEO Pro 4.5.8 - aioseo.com -->
    <meta name="description" content="Получите промокоды Яндекс Маркет за [MONTH] 2024, рабочие промокоды, скидки и акции."
    />
    <meta name="robots" content="max-image-preview:large" />
    <link rel="canonical" href="[SITE]/yandex-market-promokod" />
    <meta property="og:locale" content="ru_RU" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="Промокоды Яндекс.Маркет. [BKEYWORD]" />
    <meta property="og:description" content="Получите промокоды Яндекс Маркет за [MONTH] 2024. [BKEYWORD]. рабочие промокоды, скидки и акции."
    />
    <meta property="og:url" content="[SITE]/yandex-market-promokod" />
    <meta property="og:image" content="[SITE]/promokod/img/yandeks-market-jpg.webp" />
    <!-- All in One SEO Pro -->

    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin />
    <script type="text/javascript">
        /* <![CDATA[ */
        window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"\/promokod\/js\/wp-emoji-release.min.js?ver=6.4.3"}};
        /*! This file is auto-generated */
        !function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
        /* ]]> */
    </script>
    <style id='wp-emoji-styles-inline-css' type='text/css'>
        img.wp-smiley, img.emoji {
        		display: inline !important;
        		border: none !important;
        		box-shadow: none !important;
        		height: 1em !important;
        		width: 1em !important;
        		margin: 0 0.07em !important;
        		vertical-align: -0.1em !important;
        		background: none !important;
        		padding: 0 !important;
        	}
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='/promokod/css/style.min.css?ver=6.4.3' type='text/css' media='all' />
    <style id='classic-theme-styles-inline-css' type='text/css'>
        /*! This file is auto-generated */
        .wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
    </style>
    <style id='global-styles-inline-css' type='text/css'>
        body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
        .wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
        :where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
        :where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
        .wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
    </style>
    <link rel='stylesheet' id='redux-extendify-styles-css' href='/promokod/css/extendify-utilities.css?ver=4.4.13' type='text/css' media='all' />
    <link rel='stylesheet' id='bepassive_plugin_bpsr-css' href='/promokod/css/css.css?ver=1.4' type='text/css' media='all' />
    <link rel='stylesheet' id='contact-form-7-css' href='/promokod/css/styles.css?ver=5.9' type='text/css' media='all' />
    <link rel='stylesheet' id='wpcoupon_style-css' href='/promokod/css/style.css?ver=1.1' type='text/css' media='all' />
    <link rel='stylesheet' id='wpcoupon_semantic-css' href='/promokod/css/semantic.min.css?ver=4.2.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-users-css' href='/promokod/css/style2.css?ver=6.4.3' type='text/css' media='all' />
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=PT%20Sans:400,700,400italic,700italic&#038;subset=latin&#038;display=swap&#038;ver=1712932434" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=PT%20Sans:400,700,400italic,700italic&#038;subset=latin&#038;display=swap&#038;ver=1712932434" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=PT%20Sans:400,700,400italic,700italic&#038;subset=latin&#038;display=swap&#038;ver=1712932434" /></noscript>
    <script type="text/javascript" src="/promokod/js/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
    <script type="text/javascript" src="/promokod/js/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
    <script type="text/javascript" src="/promokod/js/frontend.min.js?ver=1.2.0" id="wp-yandex-metrika_frontend-js"></script>
    <script type="text/javascript" src="/promokod/js/js.min.js?ver=1.4" id="bepassive_plugin_bpsr_js-js"></script>
    <script type="text/javascript" src="/promokod/js/semantic.js?ver=1.1" id="wpcoupon_semantic-js"></script>
    <!--[if lt IE 8]>
<script type="text/javascript" src="/promokod/js/json2.min.js?ver=2015-05-03" id="json2-js"></script>
<![endif]-->
    <!-- <style>
        .bp-star-ratings .bpsr-star.gray{background-size:24px 24px !important;width:120px !important;}.bp-star-ratings .bpsr-star.orange{background-size:24px 24px !important;}.bp-star-ratings {display:flex;width:270px !important;}.bp-star-ratings .bpsr-stars a {width:24px; height:24px;}.bp-star-ratings .bpsr-stars, .bp-star-ratings .bpsr-stars .bpsr-fuel, .bp-star-ratings .bpsr-stars a { height:24px; }.bp-star-ratings .bpsr-star.yellow { background-image: url([SITE]/wp-content/plugins/bp-star-ratings/assets/images/yellow_star.png); background-size:24px 24px; }
    </style> -->
    <!--[if lt IE 9]><script src="/promokod/js/html5.min.js"></script><![endif]-->




    <style id="st_options-dynamic-css" title="dynamic-css" class="redux-options-output">
        body, p{font-family:"PT Sans";text-align:по центру;font-weight:400;color:#000000;font-size:16px;}h1,h2,h3,h4,h5,h6{font-family:"PT Sans";color:#000000;}
                                        #header-search .header-search-submit,
                                        .newsletter-box-wrapper.shadow-box .input .ui.button,
                                        .wpu-profile-wrapper .section-heading .button,
                                        input[type="reset"], input[type="submit"], input[type="submit"],
                                        .site-footer .widget_newsletter .newsletter-box-wrapper.shadow-box .sidebar-social a:hover,
                                        .ui.button.btn_primary,
                                        .site-footer .newsletter-box-wrapper .input .ui.button,
                                        .site-footer .footer-social a:hover,
                                        .site-footer .widget_newsletter .newsletter-box-wrapper.shadow-box .sidebar-social a:hover,
        								.coupon-filter .ui.menu .item .offer-count,
                                        .newsletter-box-wrapper.shadow-box .input .ui.button,
                                        .newsletter-box-wrapper.shadow-box .sidebar-social a:hover,
                                        .wpu-profile-wrapper .section-heading .button,
                                        .ui.btn.btn_primary,
        								.ui.button.btn_primary,
        								.coupon-filter .filter-coupons-buttons .submit-coupon-button:hover,
        								.coupon-filter .filter-coupons-buttons .submit-coupon-button.active,
        								.coupon-filter .filter-coupons-buttons .submit-coupon-button.active:hover,
        								.coupon-filter .filter-coupons-buttons .submit-coupon-button.current::after,
                                        .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce button.button.alt,
                                        .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,
                                        a.ui.button.btn.btn_secondary.go-store,
                                        button.ui.right.labeled.icon.button.btn.btn_secondary.copy-btn,
                                        .popular-stores-carousel .owl-dots .owl-dot.active
                                    {background-color:#fc9700;}
                                        .primary-color,
                                            .primary-colored,
                                            a,
                                            .ui.breadcrumb a,
                                            .screen-reader-text:hover,
                                            .screen-reader-text:active,
                                            .screen-reader-text:focus,
                                            .st-menu a:hover,
                                            .st-menu li.current-menu-item a,
                                            .nav-user-action .st-menu .menu-box a,
                                            .popular-stores .store-name a:hover,
                                            .store-listing-item .store-thumb-link .store-name a:hover,
                                            .store-listing-item .latest-coupon .coupon-title a,
                                            .store-listing-item .coupon-save:hover,
                                            .store-listing-item .coupon-saved,
                                            .coupon-modal .coupon-content .user-ratting .ui.button:hover i,
                                            .coupon-modal .coupon-content .show-detail a:hover,
                                            .coupon-modal .coupon-content .show-detail .show-detail-on,
                                            .coupon-modal .coupon-footer ul li a:hover,
                                            .coupon-listing-item .coupon-detail .user-ratting .ui.button:hover i,
                                            .coupon-listing-item .coupon-detail .user-ratting .ui.button.active i,
                                            .coupon-listing-item .coupon-listing-footer ul li a:hover, .coupon-listing-item .coupon-listing-footer ul li a.active,
                                            .coupon-listing-item .coupon-exclusive strong i,
                                            .cate-az a:hover,
                                            .cate-az .cate-parent > a,
                                            .site-footer a:hover,
                                            .site-breadcrumb .ui.breadcrumb a.section,
                                            .single-store-header .add-favorite:hover,
                                            .wpu-profile-wrapper .wpu-form-sidebar li a:hover,
                                            .ui.comments .comment a.author:hover,
                                            .primary-navigation .st-menu>li>a:hover,
                                            .popular-stores.inside-content .store-carousel .owl-next:hover,
                                            .popular-stores.inside-content .store-carousel .owl-prev:hover
                                        {color:#fc9700;}
                                        .primary-header,
                                        .store-thumb:hover,
                                        textarea:focus,
                                        input[type="date"]:focus,
                                        input[type="datetime"]:focus,
                                        input[type="datetime-local"]:focus,
                                        input[type="email"]:focus,
                                        input[type="month"]:focus,
                                        input[type="number"]:focus,
                                        input[type="password"]:focus,
                                        input[type="search"]:focus,
                                        input[type="tel"]:focus,
                                        input[type="text"]:focus,
                                        input[type="time"]:focus,
                                        input[type="url"]:focus,
                                        input[type="week"]:focus,
                                        .coupon-modal .coupon-content .modal-code .code-text,
                                        .popular-stores-carousel .owl-dots .owl-dot.active
                                    {border-color:#fc9700;}
                                        .sf-arrows > li > .sf-with-ul:focus:after,
                                        .sf-arrows > li:hover > .sf-with-ul:after,
                                        .sf-arrows > .sfHover > .sf-with-ul:after
                                    {border-top-color:#fc9700;}
                                        .sf-arrows ul li > .sf-with-ul:focus:after,
                                        .sf-arrows ul li:hover > .sf-with-ul:after,
                                        .sf-arrows ul .sfHover > .sf-with-ul:after,
                                        .entry-content blockquote
        							{border-left-color:#fc9700;}
        								.coupon-filter .filter-coupons-buttons .submit-coupon-button.current::after
        							{border-bottom-color:#fc9700;}
        								.coupon-filter .filter-coupons-buttons .submit-coupon-button.current::after
        							{border-right-color:#fc9700;}
                                       .ui.btn,
                                       .ui.btn:hover,
                                       .ui.btn.btn_secondary,
                                       .coupon-button-type .coupon-deal,
        								.coupon-filter .filter-coupons-buttons .store-filter-button .offer-count,
        							   .coupon-filter .filter-coupons-buttons .submit-coupon-button.active.current
                                    {background-color:#fc9700;}
                                        .a:hover,
                                        .secondary-color,
                                       .nav-user-action .st-menu .menu-box a:hover,
                                       .store-listing-item .latest-coupon .coupon-title a:hover,
                                       .ui.breadcrumb a:hover
                                    {color:#fc9700;}
                                        .store-thumb a:hover,
                                        .single-store-header .header-thumb .header-store-thumb a:hover
                                    {border-color:#fc9700;}
                                        .coupon-listing-item .c-type .c-code,
        							    .coupon-button-type .coupon-code .get-code,
        								.coupon-filter .ui.menu .item .code-count,
        								.coupon-filter .filter-coupons-buttons .store-filter-button .offer-count.code-count,
        								.coupon-filter .filter-coupons-buttons .store-filter-button[data-filter="code"]
                                    {background-color:#fc9700;}
                                        .c-type-code:hover,
                                        .coupon-button-type .coupon-code
                                    {border-color:#fc9700;}
                                        .coupon-button-type .coupon-code .get-code:after
        							{border-left-color:#fc9700;}
                                        .coupon-listing-item .c-type .c-sale,
        								.coupon-filter .ui.menu .item .sale-count,
        								.coupon-button-type .coupon-deal,
        								.coupon-filter .filter-coupons-buttons .store-filter-button .offer-count.sale-count,
        								.coupon-filter .filter-coupons-buttons .store-filter-button[data-filter="sale"]
                                    {background-color:#fc9700;}
                                        .c-type-sale:hover
                                    {border-color:#fc9700;}
                                        .coupon-listing-item .c-type .c-print,
        								.coupon-filter .ui.menu .item .print-count,
        								.coupon-button-type .coupon-print,
        								.coupon-filter .filter-coupons-buttons .store-filter-button .offer-count.print-count,
        								.coupon-filter .filter-coupons-buttons .store-filter-button[data-filter="print"]
                                    {background-color:#fc9700;}
                                        .c-type-print:hover
                                    {border-color:#fc9700;}body{background-color:#f8f9f9;}
    </style>
</head>

<body class="archive tax-coupon_store term-market_yandex_ru term-67 gecko windows">
    <div id="page" class="hfeed site">
        <header id="masthead" class="ui page site-header site-navigation" role="banner" id="site-header-nav">
            <div class="primary-header">
                <div class="container">
                    <div class="logo_area fleft">
                      
                        <a href="[SITE]" title="" rel="home">
                            <img rel="preload" src="/promokod/img/logotip-menshe.png" alt="" />
                        </a>
                    </div>

                    <div class="header_right fright">
                        <nav class="primary-navigation clearfix fleft" role="navigation">
                            <!--                            <div id="nav-toggle"><i class="content icon"></i></div>-->
                             <div id="nav_toggle_open" class="nav-toggle">
                                <i class="bars icon"></i>
                            </div>
                            <div id="nav_toggle_close" class="nav-toggle nav_toggle_inactive">
                                <i class="close icon"></i>
                            </div> -->
                            <ul class="st-menu">
                                <li id="menu-item-254" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-254"><a href="[SITE]/">Главная</a></li>
<li id="menu-item-249" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-249"><a href="https://vkreditke.ru/dlyadoma.php">Товары для дома</a></li>
<li id="menu-item-250" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-250"><a href="https://vkreditke.ru/odegda.php">Одежда, обувь и аксессуары</a></li>
<li id="menu-item-251" class="menu-item menu-item-type-taxonomy menu-item-object-coupon_category menu-item-251"><a href="https://vkreditke.ru/beauty.php">Красота</a></li>
<li id="menu-item-252" class="menu-item menu-item-type-taxonomy menu-item-object-coupon_category menu-item-252"><a href="https://vkreditke.ru/kids.php">Для детей</a></li>
<li id="menu-item-253" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-253"><a href="https://vkreditke.ru/sofa.php">Мебель</a></li>
<li id="menu-item-253" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-253"><a href="[SITE]/out/777">МегаМаркет</a></li>
                            </ul>
                        </nav>
                        <!-- END .primary-navigation -->
                    </div>
                </div>
            </div>
            <!-- END .header -->
        </header>
        <!-- END #masthead -->
        <div id="content" class="site-content">

            <div id="content-wrap" class="container right-sidebar">

                <!--  Store Content area  -->
                <div id="primary" class="content-area">
                    <div class="store-header d-flex">
                        <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_small_thumb size-wpcoupon_small_thumb" alt="Яндекс Маркет" title="яндекс маркет" decoding="async" />
                        <h1 class="entry-title store-title ">[BKEYWORD]</h1>
                    </div>
                    <main id="main" class="site-main coupon-store-main" role="main">
                        <section id="coupon-listings-store" class=" wpb_content_element">
                            <div class="ajax-coupons">
                                <div class="store-listings st-list-coupons couponstore-tpl-full">

                                                                    <div data-id="67" class="coupon-item no-thumb store-listing-item c-type-code coupon-listing-item shadow-box coupon-live">

                                      <div class="latest-coupon">
                                          <h3 class="coupon-title">
                                                          <a
                                                 title="Промокод Скидки на заказ "
                                                                  rel="nofollow"
                                                                 class="coupon-link"
                                                 data-type="code"
                                                 data-coupon-id="67"
                                                 data-afoof-urls="[SITE]/yandex-market-promokod/out/67"
                                                 data-code="<?php echo $code9; ?>"
                                                 href="[SITE]/yandex-market-promokod/67/"><?php echo $code8; ?> <font style="background-color:#ffeda8"></font>  </a></h3>
                                          <div class="c-type">
                                              <span class="c-code c-code">Код</span>
                                              <span class="exp">Истекает 11.07.2025</span>
                                          </div>
                                          <div class="coupon-des">
                                              <p>Бюджет акции ограничен и может закончится раньше указанного срока.</p>
                                          </div>
                                      </div>

                                      <div class="coupon-detail coupon-button-type">
                                                                                     <a rel="nofollow" data-type="code" data-coupon-id="67" href="[SITE]/yandex-market-promokod/67/"  class="coupon-button coupon-code" data-tooltip="Кликните для копирования и открытия сайта"
                                              data-position="top center"  data-code="<?php echo $code9; ?>" data-afoof-url="[SITE]/yandex-market-promokod/out/67">
                                              <span class="code-text" rel="nofollow"><?php echo $code9; ?></span>
                                              <span class="get-code">Открыть</span>
                                          </a>
                                                                                    <div class="clear"></div>
                                          <!-- <div class="user-ratting ui icon basic buttons">
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="67" data-position="top center"  data-tooltip="Работает"><i class="icon thumbs up outline"></i></div>
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="67" data-position="top center"  data-tooltip="Не работает"><i class="icon thumbs down outline"></i></div>
                                          </div> -->
                                          <!-- <span class="voted-value">100% Успешно</span> -->
                                      </div>
                                      <div class="clear"></div>
                                                                            <div class="coupon-exclusive"><strong><i class="protect icon"></i>Эксклюзив:</strong> Этот купон можно найти только на нашем сайте.</div>
                                                                            <div class="coupon-footer coupon-listing-footer">
                                          <ul class="clearfix">
                                              <!-- <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li> -->
                                              <li><a title="Поделиться с другом" data-reveal="reveal-share" href="#"><i class="share alternate icon"></i> Поделиться</a></li>
                                              <!-- <li><a title="Отправить этот купон на email" data-reveal="reveal-email" href="#"><i class="mail outline icon"></i> E-mail</a></li> -->
                                              <!-- <li><a title="Комментарии к купону" data-reveal="reveal-comments" href="#"><i class="comments outline icon"></i> 0 Комментарии</a></li> -->
                                          </ul>
                                          <div data-coupon-id="67" class="reveal-content reveal-share">
                                              <span class="close"></span>
                                              <h4>Поделиться с друзьями</h4>
                                              <div class="ui fluid left icon input">
                                                  <input value="[SITE]/yandex-market-promokod/67/" type="text">
                                                  <i class="linkify icon"></i>
                                              </div>
                                              <br>
                                              <div class="coupon-share">
                                              </div>
                                          </div>
                                          <div data-coupon-id="67" class="reveal-content reveal-email">
                                              <span class="close"></span>
                                              <h4 class="send-mail-heading">Отправить этот купон на email</h4>
                                              <div class="ui fluid action left icon input">
                                                  <input class="email_send_to" placeholder="Email адрес ..." type="text">
                                                  <i class="mail outline icon"></i>
                                                  <div class="email_send_btn ui button btn btn_primary">Отправить</div>
                                              </div><br>
                                              <p>Это не подписка на рассылку по e-mail. Ваш e-mail (или e-mail вашего друга) будет использован только для отправки этого купона.</p>
                                          </div>
                                          <div data-coupon-id="67" class="reveal-content reveal-comments">
                                              <span class="close"></span>
                                              <div data-id="67" class="comments-coupon-67 ui threaded comments">
                                                  <h4>Загрузка комментариев....</h4>
                                              </div>

                                              <h4>Пусть другие узнают, сколько вы сэкономили</h4>
                                              <form class="coupon-comment-form" data-cf="67" action="[SITE]/" method="post">

                                                  <div style="display: none;" class="ui success message">
                                                      Ваш комментарий отправлен. </div>

                                                  <div style="display: none;" class="ui negative message">
                                                      Что-то пошло не так! Пожалуйста, повторите попытку позже. </div>

                                                  <div class="ui form">
                                                      <div class="field comment_content">
                                                          <textarea class="comment_content" name="c_comment[comment_content]" placeholder="Добавить комментарий"></textarea>
                                                      </div>
                                                      <div class="two fields">
                                                          <div class="field comment_author">
                                                              <input type="text" class="comment_author" name="c_comment[comment_author]" placeholder="Ваше имя">
                                                          </div>
                                                          <div class="field comment_author_email">
                                                              <input type="text" class="comment_author_email" name="c_comment[comment_author_email]" placeholder="Ваш e-mail">
                                                          </div>
                                                      </div>
                                                      <button type="submit" class="ui button btn btn_primary">Отправить</button>
                                                  </div>
                                                  <input type="hidden" name="action" value="wpcoupon_coupon_ajax">
                                                  <input type="hidden" name="st_doing" value="new_comment">
                                                  <input type="hidden" name="_wpnonce" value="668ed1eb677e5">
                                                  <input type="hidden" name="c_comment[comment_parent]" class="comment_parent">
                                                  <input type="hidden" name="c_comment[comment_post_ID]" value="67" class="comment_post_ID">
                                              </form>
                                          </div>
                                      </div>
                                      <!-- Coupon Modal -->
                                      <div data-modal-id="67" class="ui modal coupon-modal coupon-code-modal">
                                          <div class="scrolling content">
                                              <div class="coupon-header clearfix">
                                                  <div class="coupon-store-thumb">
                                                      <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_medium-thumb size-wpcoupon_medium-thumb" alt="" title="яндекс маркет" decoding="async" /> </div>
                                                  <div class="coupon-title" title="МегаРаспродажа и только свежие акции на МегаМаркет">МегаРаспродажа и только свежие акции на МегаМаркет </div>
                                                  <span class="close icon"></span>
                                              </div>
                                              <div class="coupon-content">
                                                  <p class="coupon-type-text">
                                                                                                        Скопируйте этот код и используйте при оформлении заказа
                                                                                                      </p>
                                                  <div class="modal-code">
                                                                                                          <div class="coupon-code">
                                                          <div class="ui fluid action input massive">
                                                              <input type="text" class="code-text" autocomplete="off" readonly value="ВшитВСсылку">
                                                              <button class="ui right labeled icon button btn btn_secondary copy-btn">
                                                                      <i class="copy icon"></i>
                                                                      <span>Копировать</span>
                                                                  </button>
                                                          </div>
                                                      </div>
                                                                                                      </div>
                                                  <div class="clearfix">
                                                      <!-- <div class="user-ratting ui icon basic buttons">
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="67" data-position="top center"  data-tooltip="Работает"><i class="smile outline icon"></i></div>
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="67" data-position="top center"  data-tooltip="Не работает"><i class="frown outline icon"></i></div>
                                                      </div> -->

                                                                                                              <a href="[SITE]/yandex-market-promokod/out/99" rel="nofollow" target="_blank" class="ui button btn btn_secondary go-store">Товары в Категории<i class="angle right icon"></i></a>
                                                      
                                                  </div>
                                                  <div class="clearfixp">
                                                      <!-- <span class="user-ratting-text">Не работает?</span> -->
                                                      <span class="show-detail"><a href="#">Детали купона<i class="angle down icon"></i></a></span>
                                                  </div>
                                                  <div class="coupon-popup-detail">
                                                      <div class="coupon-detail-content">
                                                          <p>Бюджет акции ограничен и может закончится раньше указанного срока.</p>
                                                      </div>
                                                      <p><strong>Истекает</strong>: Истекает 11.07.2025</p>
                                                      <!-- <p><strong>Отправлено</strong>: 2 дня назад </p> -->
                                                  </div>
                                              </div>
                                              <div class="coupon-footer">
                                                  <!-- <ul class="clearfix">
                                                      <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li>
                                                  </ul> -->

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                                                    <div data-id="70" class="coupon-item no-thumb store-listing-item c-type-code coupon-listing-item shadow-box coupon-live">

                                      <div class="latest-coupon">
                                          <h3 class="coupon-title">
                                                          <a
                                                 title="<?php echo $code10; ?>"
                                                                  rel="nofollow"
                                                                 class="coupon-link"
                                                 data-type="code"
                                                 data-coupon-id="70"
                                                 data-afoof-urls="[SITE]/yandex-market-promokod/out/70"
                                                 data-code="<?php echo $code11; ?>"
                                                 href="[SITE]/yandex-market-promokod/70/"><?php echo $code10; ?></a></h3>
                                          <div class="c-type">
                                              <span class="c-code c-code">Код</span>
                                              <span class="exp">Истекает 26.07.2025</span>
                                          </div>
                                          <div class="coupon-des">
                                              <p>Скопируйте этот код и используйте при оформлении заказа </p>
                                          </div>
                                      </div>

                                      <div class="coupon-detail coupon-button-type">
                                                                                    <a rel="nofollow" data-type="code" data-coupon-id="70" href="[SITE]/yandex-market-promokod/70/"  class="coupon-button coupon-code" data-tooltip="Кликните для копирования и открытия сайта"
                                              data-position="top center"  data-code="<?php echo $code11; ?>" data-afoof-url="[SITE]/yandex-market-promokod/out/70">
                                              <span class="code-text" rel="nofollow"><?php echo $code11; ?></span>
                                              <span class="get-code">Открыть</span>
                                          </a>
                                                                                    <div class="clear"></div>
                                          <!-- <div class="user-ratting ui icon basic buttons">
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="70" data-position="top center"  data-tooltip="Работает"><i class="icon thumbs up outline"></i></div>
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="70" data-position="top center"  data-tooltip="Не работает"><i class="icon thumbs down outline"></i></div>
                                          </div> -->
                                          <!-- <span class="voted-value">100% Успешно</span> -->
                                      </div>
                                      <div class="clear"></div>
                                                                            <div class="coupon-footer coupon-listing-footer">
                                          <ul class="clearfix">
                                              <!-- <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li> -->
                                              <li><a title="Поделиться с другом" data-reveal="reveal-share" href="#"><i class="share alternate icon"></i> Поделиться</a></li>
                                              <!-- <li><a title="Отправить этот купон на email" data-reveal="reveal-email" href="#"><i class="mail outline icon"></i> E-mail</a></li> -->
                                              <!-- <li><a title="Комментарии к купону" data-reveal="reveal-comments" href="#"><i class="comments outline icon"></i> 0 Комментарии</a></li> -->
                                          </ul>
                                          <div data-coupon-id="70" class="reveal-content reveal-share">
                                              <span class="close"></span>
                                              <h4>Поделиться с друзьями</h4>
                                              <div class="ui fluid left icon input">
                                                  <input value="[SITE]/yandex-market-promokod/70/" type="text">
                                                  <i class="linkify icon"></i>
                                              </div>
                                              <br>
                                              <div class="coupon-share">
                                              </div>
                                          </div>
                                          <div data-coupon-id="70" class="reveal-content reveal-email">
                                              <span class="close"></span>
                                              <h4 class="send-mail-heading">Отправить этот купон на email</h4>
                                              <div class="ui fluid action left icon input">
                                                  <input class="email_send_to" placeholder="Email адрес ..." type="text">
                                                  <i class="mail outline icon"></i>
                                                  <div class="email_send_btn ui button btn btn_primary">Отправить</div>
                                              </div><br>
                                              <p>Это не подписка на рассылку по e-mail. Ваш e-mail (или e-mail вашего друга) будет использован только для отправки этого купона.</p>
                                          </div>
                                          <div data-coupon-id="70" class="reveal-content reveal-comments">
                                              <span class="close"></span>
                                              <div data-id="70" class="comments-coupon-70 ui threaded comments">
                                                  <h4>Загрузка комментариев....</h4>
                                              </div>

                                              <h4>Пусть другие узнают, сколько вы сэкономили</h4>
                                              <form class="coupon-comment-form" data-cf="70" action="[SITE]/" method="post">

                                                  <div style="display: none;" class="ui success message">
                                                      Ваш комментарий отправлен. </div>

                                                  <div style="display: none;" class="ui negative message">
                                                      Что-то пошло не так! Пожалуйста, повторите попытку позже. </div>

                                                  <div class="ui form">
                                                      <div class="field comment_content">
                                                          <textarea class="comment_content" name="c_comment[comment_content]" placeholder="Добавить комментарий"></textarea>
                                                      </div>
                                                      <div class="two fields">
                                                          <div class="field comment_author">
                                                              <input type="text" class="comment_author" name="c_comment[comment_author]" placeholder="Ваше имя">
                                                          </div>
                                                          <div class="field comment_author_email">
                                                              <input type="text" class="comment_author_email" name="c_comment[comment_author_email]" placeholder="Ваш e-mail">
                                                          </div>
                                                      </div>
                                                      <button type="submit" class="ui button btn btn_primary">Отправить</button>
                                                  </div>
                                                  <input type="hidden" name="action" value="wpcoupon_coupon_ajax">
                                                  <input type="hidden" name="st_doing" value="new_comment">
                                                  <input type="hidden" name="_wpnonce" value="668ed1eb677f2">
                                                  <input type="hidden" name="c_comment[comment_parent]" class="comment_parent">
                                                  <input type="hidden" name="c_comment[comment_post_ID]" value="70" class="comment_post_ID">
                                              </form>
                                          </div>
                                      </div>
                                      <!-- Coupon Modal -->
                                      <div data-modal-id="70" class="ui modal coupon-modal coupon-code-modal">
                                          <div class="scrolling content">
                                              <div class="coupon-header clearfix">
                                                  <div class="coupon-store-thumb">
                                                      <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_medium-thumb size-wpcoupon_medium-thumb" alt="" title="яндекс маркет" decoding="async" /> </div>
                                                  <div class="coupon-title" title="<?php echo $code10; ?>"><?php echo $code10; ?></div>
                                                  <span class="close icon"></span>
                                              </div>
                                              <div class="coupon-content">
                                                  <p class="coupon-type-text">
                                                                                                        Скопируйте этот код и используйте при оформлении заказа
                                                                                                      </p>
                                                  <div class="modal-code">
                                                                                                          <div class="coupon-code">
                                                          <div class="ui fluid action input massive">
                                                              <input type="text" class="code-text" autocomplete="off" readonly value="<?php echo $code11; ?>">
                                                              <button class="ui right labeled icon button btn btn_secondary copy-btn">
                                                                      <i class="copy icon"></i>
                                                                      <span>Копировать</span>
                                                                  </button>
                                                          </div>
                                                      </div>
                                                                                                      </div>
                                                  <div class="clearfix">
                                                      <!-- <div class="user-ratting ui icon basic buttons">
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="70" data-position="top center"  data-tooltip="Работает"><i class="smile outline icon"></i></div>
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="70" data-position="top center"  data-tooltip="Не работает"><i class="frown outline icon"></i></div>
                                                      </div> -->

                                                                                                              <a href="[SITE]/yandex-market-promokod/out/70" rel="nofollow" target="_blank" class="ui button btn btn_secondary go-store">Товары в Категории<i class="angle right icon"></i></a>
                                                      
                                                  </div>
                                                  <div class="clearfixp">
                                                      <!-- <span class="user-ratting-text">Не работает?</span> -->
                                                      <span class="show-detail"><a href="#">Детали купона<i class="angle down icon"></i></a></span>
                                                  </div>
                                                  <div class="coupon-popup-detail">
                                                      <div class="coupon-detail-content">
                                                          <p>Скопируйте этот код и используйте при оформлении заказа </p>
                                                      </div>
                                                      <p><strong>Истекает</strong>: Истекает 26.07.2025</p>
                                                      <!-- <p><strong>Отправлено</strong>: 2 дня назад </p> -->
                                                  </div>
                                              </div>
                                              <div class="coupon-footer">
                                                  <!-- <ul class="clearfix">
                                                      <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li>
                                                  </ul> -->

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                                                    <div data-id="86" class="coupon-item no-thumb store-listing-item c-type-code coupon-listing-item shadow-box coupon-live">

                                      <div class="latest-coupon">
                                          <h3 class="coupon-title">
                                                          <a
                                                 title="<?php echo $code12; ?>"
                                                                  rel="nofollow"
                                                                 class="coupon-link"
                                                 data-type="code"
                                                 data-coupon-id="86"
                                                 data-afoof-urls="[SITE]/yandex-market-promokod/out/86"
                                                 data-code="<?php echo $code13; ?> "
                                                 href="[SITE]/yandex-market-promokod/86/"><?php echo $code12; ?></a></h3>
                                          <div class="c-type">
                                              <span class="c-code c-code">Код</span>
                                              <span class="exp">Истекает 31.07.2025</span>
                                          </div>
                                          <div class="coupon-des">
                                              <p>Скопируйте этот код и используйте при оформлении заказа </p>
                                          </div>
                                      </div>

                                      <div class="coupon-detail coupon-button-type">
                                                                                    <a rel="nofollow" data-type="code" data-coupon-id="86" href="[SITE]/yandex-market-promokod/86/"  class="coupon-button coupon-code" data-tooltip="Кликните для копирования и открытия сайта"
                                              data-position="top center"  data-code="<?php echo $code13; ?>" data-afoof-url="[SITE]/yandex-market-promokod/out/86">
                                              <span class="code-text" rel="nofollow"><?php echo $code13; ?></span>
                                              <span class="get-code">Открыть</span>
                                          </a>
                                                                                    <div class="clear"></div>
                                          <!-- <div class="user-ratting ui icon basic buttons">
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="86" data-position="top center"  data-tooltip="Работает"><i class="icon thumbs up outline"></i></div>
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="86" data-position="top center"  data-tooltip="Не работает"><i class="icon thumbs down outline"></i></div>
                                          </div> -->
                                          <!-- <span class="voted-value">100% Успешно</span> -->
                                      </div>
                                      <div class="clear"></div>
                                                                            <div class="coupon-footer coupon-listing-footer">
                                          <ul class="clearfix">
                                              <!-- <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li> -->
                                              <li><a title="Поделиться с другом" data-reveal="reveal-share" href="#"><i class="share alternate icon"></i> Поделиться</a></li>
                                              <!-- <li><a title="Отправить этот купон на email" data-reveal="reveal-email" href="#"><i class="mail outline icon"></i> E-mail</a></li> -->
                                              <!-- <li><a title="Комментарии к купону" data-reveal="reveal-comments" href="#"><i class="comments outline icon"></i> 0 Комментарии</a></li> -->
                                          </ul>
                                          <div data-coupon-id="86" class="reveal-content reveal-share">
                                              <span class="close"></span>
                                              <h4>Поделиться с друзьями</h4>
                                              <div class="ui fluid left icon input">
                                                  <input value="[SITE]/yandex-market-promokod/86/" type="text">
                                                  <i class="linkify icon"></i>
                                              </div>
                                              <br>
                                              <div class="coupon-share">
                                              </div>
                                          </div>
                                          <div data-coupon-id="86" class="reveal-content reveal-email">
                                              <span class="close"></span>
                                              <h4 class="send-mail-heading">Отправить этот купон на email</h4>
                                              <div class="ui fluid action left icon input">
                                                  <input class="email_send_to" placeholder="Email адрес ..." type="text">
                                                  <i class="mail outline icon"></i>
                                                  <div class="email_send_btn ui button btn btn_primary">Отправить</div>
                                              </div><br>
                                              <p>Это не подписка на рассылку по e-mail. Ваш e-mail (или e-mail вашего друга) будет использован только для отправки этого купона.</p>
                                          </div>
                                          <div data-coupon-id="86" class="reveal-content reveal-comments">
                                              <span class="close"></span>
                                              <div data-id="86" class="comments-coupon-86 ui threaded comments">
                                                  <h4>Загрузка комментариев....</h4>
                                              </div>

                                              <h4>Пусть другие узнают, сколько вы сэкономили</h4>
                                              <form class="coupon-comment-form" data-cf="86" action="[SITE]/" method="post">

                                                  <div style="display: none;" class="ui success message">
                                                      Ваш комментарий отправлен. </div>

                                                  <div style="display: none;" class="ui negative message">
                                                      Что-то пошло не так! Пожалуйста, повторите попытку позже. </div>

                                                  <div class="ui form">
                                                      <div class="field comment_content">
                                                          <textarea class="comment_content" name="c_comment[comment_content]" placeholder="Добавить комментарий"></textarea>
                                                      </div>
                                                      <div class="two fields">
                                                          <div class="field comment_author">
                                                              <input type="text" class="comment_author" name="c_comment[comment_author]" placeholder="Ваше имя">
                                                          </div>
                                                          <div class="field comment_author_email">
                                                              <input type="text" class="comment_author_email" name="c_comment[comment_author_email]" placeholder="Ваш e-mail">
                                                          </div>
                                                      </div>
                                                      <button type="submit" class="ui button btn btn_primary">Отправить</button>
                                                  </div>
                                                  <input type="hidden" name="action" value="wpcoupon_coupon_ajax">
                                                  <input type="hidden" name="st_doing" value="new_comment">
                                                  <input type="hidden" name="_wpnonce" value="668ed1eb677fe">
                                                  <input type="hidden" name="c_comment[comment_parent]" class="comment_parent">
                                                  <input type="hidden" name="c_comment[comment_post_ID]" value="86" class="comment_post_ID">
                                              </form>
                                          </div>
                                      </div>
                                      <!-- Coupon Modal -->
                                      <div data-modal-id="86" class="ui modal coupon-modal coupon-code-modal">
                                          <div class="scrolling content">
                                              <div class="coupon-header clearfix">
                                                  <div class="coupon-store-thumb">
                                                      <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_medium-thumb size-wpcoupon_medium-thumb" alt="" title="яндекс маркет" decoding="async" /> </div>
                                                  <div class="coupon-title" title="<?php echo $code12; ?>"><?php echo $code12; ?></div>
                                                  <span class="close icon"></span>
                                              </div>
                                              <div class="coupon-content">
                                                  <p class="coupon-type-text">
                                                                                                        Скопируйте этот код и используйте при оформлении заказа
                                                                                                      </p>
                                                  <div class="modal-code">
                                                                                                          <div class="coupon-code">
                                                          <div class="ui fluid action input massive">
                                                              <input type="text" class="code-text" autocomplete="off" readonly value="<?php echo $code13; ?> ">
                                                              <button class="ui right labeled icon button btn btn_secondary copy-btn">
                                                                      <i class="copy icon"></i>
                                                                      <span>Копировать</span>
                                                                  </button>
                                                          </div>
                                                      </div>
                                                                                                      </div>
                                                  <div class="clearfix">
                                                      <!-- <div class="user-ratting ui icon basic buttons">
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="86" data-position="top center"  data-tooltip="Работает"><i class="smile outline icon"></i></div>
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="86" data-position="top center"  data-tooltip="Не работает"><i class="frown outline icon"></i></div>
                                                      </div> -->

                                                                                                              <a href="[SITE]/yandex-market-promokod/out/86" rel="nofollow" target="_blank" class="ui button btn btn_secondary go-store">Товары в Категории<i class="angle right icon"></i></a>
                                                      
                                                  </div>
                                                  <div class="clearfixp">
                                                      <!-- <span class="user-ratting-text">Не работает?</span> -->
                                                      <span class="show-detail"><a href="#">Детали купона<i class="angle down icon"></i></a></span>
                                                  </div>
                                                  <div class="coupon-popup-detail">
                                                      <div class="coupon-detail-content">
                                                          <p>Скопируйте этот код и используйте при оформлении заказа </p>
                                                      </div>
                                                      <p><strong>Истекает</strong>: Истекает 31.07.2025</p>
                                                      <!-- <p><strong>Отправлено</strong>: 2 дня назад </p> -->
                                                  </div>
                                              </div>
                                              <div class="coupon-footer">
                                                  <!-- <ul class="clearfix">
                                                      <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li>
                                                  </ul> -->

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                                                    <div data-id="72" class="coupon-item no-thumb store-listing-item c-type-code coupon-listing-item shadow-box coupon-live">

                                      <div class="latest-coupon">
                                          <h3 class="coupon-title">
                                                          <a
                                                 title="<?php echo $code14; ?>"
                                                                  rel="nofollow"
                                                                 class="coupon-link"
                                                 data-type="code"
                                                 data-coupon-id="72"
                                                 data-afoof-urls="[SITE]/yandex-market-promokod/out/72"
                                                 data-code="<?php echo $code15; ?>"
                                                 href="[SITE]/yandex-market-promokod/72/"><?php echo $code14; ?></a></h3>
                                          <div class="c-type">
                                              <span class="c-code c-code">Код</span>
                                              <span class="exp">Истекает 14.07.2025</span>
                                          </div>
                                          <div class="coupon-des">
                                              <p>Скопируйте этот код и используйте при оформлении заказа </p>
                                          </div>
                                      </div>

                                      <div class="coupon-detail coupon-button-type">
                                                                                    <a rel="nofollow" data-type="code" data-coupon-id="72" href="[SITE]/yandex-market-promokod/72/"  class="coupon-button coupon-code" data-tooltip="Кликните для копирования и открытия сайта"
                                              data-position="top center"  data-code="<?php echo $code15; ?>" data-afoof-url="[SITE]/yandex-market-promokod/out/72">
                                              <span class="code-text" rel="nofollow"><?php echo $code15; ?></span>
                                              <span class="get-code">Открыть</span>
                                          </a>
                                                                                    <div class="clear"></div>
                                          <!-- <div class="user-ratting ui icon basic buttons">
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="72" data-position="top center"  data-tooltip="Работает"><i class="icon thumbs up outline"></i></div>
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="72" data-position="top center"  data-tooltip="Не работает"><i class="icon thumbs down outline"></i></div>
                                          </div> -->
                                          <!-- <span class="voted-value">100% Успешно</span> -->
                                      </div>
                                      <div class="clear"></div>
                                                                            <div class="coupon-footer coupon-listing-footer">
                                          <ul class="clearfix">
                                              <!-- <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li> -->
                                              <li><a title="Поделиться с другом" data-reveal="reveal-share" href="#"><i class="share alternate icon"></i> Поделиться</a></li>
                                              <!-- <li><a title="Отправить этот купон на email" data-reveal="reveal-email" href="#"><i class="mail outline icon"></i> E-mail</a></li> -->
                                              <!-- <li><a title="Комментарии к купону" data-reveal="reveal-comments" href="#"><i class="comments outline icon"></i> 0 Комментарии</a></li> -->
                                          </ul>
                                          <div data-coupon-id="72" class="reveal-content reveal-share">
                                              <span class="close"></span>
                                              <h4>Поделиться с друзьями</h4>
                                              <div class="ui fluid left icon input">
                                                  <input value="[SITE]/yandex-market-promokod/72/" type="text">
                                                  <i class="linkify icon"></i>
                                              </div>
                                              <br>
                                              <div class="coupon-share">
                                              </div>
                                          </div>
                                          <div data-coupon-id="72" class="reveal-content reveal-email">
                                              <span class="close"></span>
                                              <h4 class="send-mail-heading">Отправить этот купон на email</h4>
                                              <div class="ui fluid action left icon input">
                                                  <input class="email_send_to" placeholder="Email адрес ..." type="text">
                                                  <i class="mail outline icon"></i>
                                                  <div class="email_send_btn ui button btn btn_primary">Отправить</div>
                                              </div><br>
                                              <p>Это не подписка на рассылку по e-mail. Ваш e-mail (или e-mail вашего друга) будет использован только для отправки этого купона.</p>
                                          </div>
                                          <div data-coupon-id="72" class="reveal-content reveal-comments">
                                              <span class="close"></span>
                                              <div data-id="72" class="comments-coupon-72 ui threaded comments">
                                                  <h4>Загрузка комментариев....</h4>
                                              </div>

                                              <h4>Пусть другие узнают, сколько вы сэкономили</h4>
                                              <form class="coupon-comment-form" data-cf="72" action="[SITE]/" method="post">

                                                  <div style="display: none;" class="ui success message">
                                                      Ваш комментарий отправлен. </div>

                                                  <div style="display: none;" class="ui negative message">
                                                      Что-то пошло не так! Пожалуйста, повторите попытку позже. </div>

                                                  <div class="ui form">
                                                      <div class="field comment_content">
                                                          <textarea class="comment_content" name="c_comment[comment_content]" placeholder="Добавить комментарий"></textarea>
                                                      </div>
                                                      <div class="two fields">
                                                          <div class="field comment_author">
                                                              <input type="text" class="comment_author" name="c_comment[comment_author]" placeholder="Ваше имя">
                                                          </div>
                                                          <div class="field comment_author_email">
                                                              <input type="text" class="comment_author_email" name="c_comment[comment_author_email]" placeholder="Ваш e-mail">
                                                          </div>
                                                      </div>
                                                      <button type="submit" class="ui button btn btn_primary">Отправить</button>
                                                  </div>
                                                  <input type="hidden" name="action" value="wpcoupon_coupon_ajax">
                                                  <input type="hidden" name="st_doing" value="new_comment">
                                                  <input type="hidden" name="_wpnonce" value="668ed1eb67809">
                                                  <input type="hidden" name="c_comment[comment_parent]" class="comment_parent">
                                                  <input type="hidden" name="c_comment[comment_post_ID]" value="72" class="comment_post_ID">
                                              </form>
                                          </div>
                                      </div>
                                      <!-- Coupon Modal -->
                                      <div data-modal-id="72" class="ui modal coupon-modal coupon-code-modal">
                                          <div class="scrolling content">
                                              <div class="coupon-header clearfix">
                                                  <div class="coupon-store-thumb">
                                                      <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_medium-thumb size-wpcoupon_medium-thumb" alt="" title="яндекс маркет" decoding="async" /> </div>
                                                  <div class="coupon-title" title="<?php echo $code14; ?>"><?php echo $code14; ?></div>
                                                  <span class="close icon"></span>
                                              </div>
                                              <div class="coupon-content">
                                                  <p class="coupon-type-text">
                                                                                                        Скопируйте этот код и используйте при оформлении заказа
                                                                                                      </p>
                                                  <div class="modal-code">
                                                                                                          <div class="coupon-code">
                                                          <div class="ui fluid action input massive">
                                                              <input type="text" class="code-text" autocomplete="off" readonly value="<?php echo $code15; ?>">
                                                              <button class="ui right labeled icon button btn btn_secondary copy-btn">
                                                                      <i class="copy icon"></i>
                                                                      <span>Копировать</span>
                                                                  </button>
                                                          </div>
                                                      </div>
                                                                                                      </div>
                                                  <div class="clearfix">
                                                      <!-- <div class="user-ratting ui icon basic buttons">
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="72" data-position="top center"  data-tooltip="Работает"><i class="smile outline icon"></i></div>
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="72" data-position="top center"  data-tooltip="Не работает"><i class="frown outline icon"></i></div>
                                                      </div> -->

                                                                                                              <a href="[SITE]/yandex-market-promokod/out/72" rel="nofollow" target="_blank" class="ui button btn btn_secondary go-store">Товары в Категории<i class="angle right icon"></i></a>
                                                      
                                                  </div>
                                                  <div class="clearfixp">
                                                      <!-- <span class="user-ratting-text">Не работает?</span> -->
                                                      <span class="show-detail"><a href="#">Детали купона<i class="angle down icon"></i></a></span>
                                                  </div>
                                                  <div class="coupon-popup-detail">
                                                      <div class="coupon-detail-content">
                                                          <p>Скопируйте этот код и используйте при оформлении заказа </p>
                                                      </div>
                                                      <p><strong>Истекает</strong>: Истекает 14.07.2025</p>
                                                      <!-- <p><strong>Отправлено</strong>: 2 дня назад </p> -->
                                                  </div>
                                              </div>
                                              <div class="coupon-footer">
                                                  <!-- <ul class="clearfix">
                                                      <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li>
                                                  </ul> -->

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                                                    <div data-id="49" class="coupon-item no-thumb store-listing-item c-type-sale coupon-listing-item shadow-box coupon-live">

                                      <div class="latest-coupon">
                                          <h3 class="coupon-title">
                                                          <a
                                                 title="<?php echo $code16; ?>"
                                                                  rel="nofollow"
                                                                 class="coupon-link"
                                                 data-type="code"
                                                 data-coupon-id="49"
                                                 data-afoof-urls="[SITE]/yandex-market-promokod/out/49"
                                                 data-code="<?php echo $code17; ?>"
                                                 href="[SITE]/yandex-market-promokod/49/"><?php echo $code16; ?></a></h3>
                                          <div class="c-type">
                                              <span class="c-code c-sale">Распродажа</span>
                                              <span class="exp">Истекает 14.07.2025</span>
                                          </div>
                                          <div class="coupon-des">
                                              <p>Подробности акции при переходе по ссылке.</p>
                                          </div>
                                      </div>

                                      <div class="coupon-detail coupon-button-type">
                                                                                      <a rel="nofollow" data-type="code" data-coupon-id="49" href="[SITE]/yandex-market-promokod/49/"  class="coupon-button coupon-code" data-tooltip="Кликните для копирования и открытия сайта"
                                              data-position="top center"  data-code="<?php echo $code17; ?>" data-afoof-url="[SITE]/yandex-market-promokod/out/49">
                                              <span class="code-text" rel="nofollow"><?php echo $code17; ?></span>
                                              <span class="get-code">Открыть</span>
                                          </a>
                                                                                    <div class="clear"></div>
                                          <!-- <div class="user-ratting ui icon basic buttons">
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="49" data-position="top center"  data-tooltip="Работает"><i class="icon thumbs up outline"></i></div>
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="49" data-position="top center"  data-tooltip="Не работает"><i class="icon thumbs down outline"></i></div>
                                          </div> -->
                                          <!-- <span class="voted-value">100% Успешно</span> -->
                                      </div>
                                      <div class="clear"></div>
                                                                            <div class="coupon-footer coupon-listing-footer">
                                          <ul class="clearfix">
                                              <!-- <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li> -->
                                              <li><a title="Поделиться с другом" data-reveal="reveal-share" href="#"><i class="share alternate icon"></i> Поделиться</a></li>
                                              <!-- <li><a title="Отправить этот купон на email" data-reveal="reveal-email" href="#"><i class="mail outline icon"></i> E-mail</a></li> -->
                                              <!-- <li><a title="Комментарии к купону" data-reveal="reveal-comments" href="#"><i class="comments outline icon"></i> 0 Комментарии</a></li> -->
                                          </ul>
                                          <div data-coupon-id="49" class="reveal-content reveal-share">
                                              <span class="close"></span>
                                              <h4>Поделиться с друзьями</h4>
                                              <div class="ui fluid left icon input">
                                                  <input value="[SITE]/yandex-market-promokod/49/" type="text">
                                                  <i class="linkify icon"></i>
                                              </div>
                                              <br>
                                              <div class="coupon-share">
                                              </div>
                                          </div>
                                          <div data-coupon-id="49" class="reveal-content reveal-email">
                                              <span class="close"></span>
                                              <h4 class="send-mail-heading">Отправить этот купон на email</h4>
                                              <div class="ui fluid action left icon input">
                                                  <input class="email_send_to" placeholder="Email адрес ..." type="text">
                                                  <i class="mail outline icon"></i>
                                                  <div class="email_send_btn ui button btn btn_primary">Отправить</div>
                                              </div><br>
                                              <p>Это не подписка на рассылку по e-mail. Ваш e-mail (или e-mail вашего друга) будет использован только для отправки этого купона.</p>
                                          </div>
                                          <div data-coupon-id="49" class="reveal-content reveal-comments">
                                              <span class="close"></span>
                                              <div data-id="49" class="comments-coupon-49 ui threaded comments">
                                                  <h4>Загрузка комментариев....</h4>
                                              </div>

                                              <h4>Пусть другие узнают, сколько вы сэкономили</h4>
                                              <form class="coupon-comment-form" data-cf="49" action="[SITE]/" method="post">

                                                  <div style="display: none;" class="ui success message">
                                                      Ваш комментарий отправлен. </div>

                                                  <div style="display: none;" class="ui negative message">
                                                      Что-то пошло не так! Пожалуйста, повторите попытку позже. </div>

                                                  <div class="ui form">
                                                      <div class="field comment_content">
                                                          <textarea class="comment_content" name="c_comment[comment_content]" placeholder="Добавить комментарий"></textarea>
                                                      </div>
                                                      <div class="two fields">
                                                          <div class="field comment_author">
                                                              <input type="text" class="comment_author" name="c_comment[comment_author]" placeholder="Ваше имя">
                                                          </div>
                                                          <div class="field comment_author_email">
                                                              <input type="text" class="comment_author_email" name="c_comment[comment_author_email]" placeholder="Ваш e-mail">
                                                          </div>
                                                      </div>
                                                      <button type="submit" class="ui button btn btn_primary">Отправить</button>
                                                  </div>
                                                  <input type="hidden" name="action" value="wpcoupon_coupon_ajax">
                                                  <input type="hidden" name="st_doing" value="new_comment">
                                                  <input type="hidden" name="_wpnonce" value="668ed1eb67814">
                                                  <input type="hidden" name="c_comment[comment_parent]" class="comment_parent">
                                                  <input type="hidden" name="c_comment[comment_post_ID]" value="49" class="comment_post_ID">
                                              </form>
                                          </div>
                                      </div>
                                      <!-- Coupon Modal -->
                                      <div data-modal-id="49" class="ui modal coupon-modal coupon-code-modal">
                                          <div class="scrolling content">
                                              <div class="coupon-header clearfix">
                                                  <div class="coupon-store-thumb">
                                                      <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_medium-thumb size-wpcoupon_medium-thumb" alt="" title="яндекс маркет" decoding="async" /> </div>
                                                  <div class="coupon-title" title="<?php echo $code16; ?>"><?php echo $code16; ?></div>
                                                  <span class="close icon"></span>
                                              </div>
                                              <div class="coupon-content">
                                                  <p class="coupon-type-text">
                                                                                                       <?php echo $code17; ?>
                                                                                                      </p>
                                                  <div class="modal-code">
                                                                                                          <a class="ui button btn btn_secondary deal-actived" target="_blank" rel="nofollow" href="[SITE]/yandex-market-promokod/out/49">Товары в Категории<i class="angle right icon"></i></a>
                                                                                                      </div>
                                                  <div class="clearfix">
                                                      <!-- <div class="user-ratting ui icon basic buttons">
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="49" data-position="top center"  data-tooltip="Работает"><i class="smile outline icon"></i></div>
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="49" data-position="top center"  data-tooltip="Не работает"><i class="frown outline icon"></i></div>
                                                      </div> -->

                                                      
                                                  </div>
                                                  <div class="clearfixp">
                                                      <!-- <span class="user-ratting-text">Не работает?</span> -->
                                                      <span class="show-detail"><a href="#">Детали купона<i class="angle down icon"></i></a></span>
                                                  </div>
                                                  <div class="coupon-popup-detail">
                                                      <div class="coupon-detail-content">
                                                          <p>Подробности акции при переходе по ссылке.</p>
                                                      </div>
                                                      <p><strong>Истекает</strong>: Истекает 14.07.2025</p>
                                                      <!-- <p><strong>Отправлено</strong>: 2 дня назад </p> -->
                                                  </div>
                                              </div>
                                              <div class="coupon-footer">
                                                  <!-- <ul class="clearfix">
                                                      <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li>
                                                  </ul> -->

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                                                    <div data-id="99" class="coupon-item no-thumb store-listing-item c-type-sale coupon-listing-item shadow-box coupon-live">

                                      <div class="latest-coupon">
                                          <h3 class="coupon-title">
                                                          <a
                                                 title="МегаРаспродажа и только свежие акции на МегаМаркет"
                                                                  rel="nofollow"
                                                                 class="coupon-link"
                                                 data-type="code"
                                                 data-coupon-id="99"
                                                 data-afoof-urls="[SITE]/yandex-market-promokod/out/99"
                                                 data-code=""
                                                 href="[SITE]/yandex-market-promokod/99/">МегаРаспродажа и только свежие акции на МегаМаркет</a></h3>
                                          <div class="c-type">
                                              <span class="c-code c-sale">Распродажа</span>
                                              <span class="exp">Истекает 11.07.2025</span>
                                          </div>
                                          <div class="coupon-des">
                                              <p>Подробности акции при переходе по ссылке.</p>
                                          </div>
                                      </div>

                                      <div class="coupon-detail coupon-button-type">
                                                                                      <a rel="nofollow" data-type="code" data-coupon-id="99" data-afoof-urls="[SITE]/yandex-market-promokod/out/99" class="coupon-deal coupon-button" href="[SITE]/yandex-market-promokod/99/">Получить <i class="shop icon"></i></a>
                                                                                    <div class="clear"></div>
                                          <!-- <div class="user-ratting ui icon basic buttons">
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="99" data-position="top center"  data-tooltip="Работает"><i class="icon thumbs up outline"></i></div>
                                              <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="99" data-position="top center"  data-tooltip="Не работает"><i class="icon thumbs down outline"></i></div>
                                          </div> -->
                                          <!-- <span class="voted-value">100% Успешно</span> -->
                                      </div>
                                      <div class="clear"></div>
                                                                            <div class="coupon-footer coupon-listing-footer">
                                          <ul class="clearfix">
                                              <!-- <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li> -->
                                              <li><a title="Поделиться с другом" data-reveal="reveal-share" href="#"><i class="share alternate icon"></i> Поделиться</a></li>
                                              <!-- <li><a title="Отправить этот купон на email" data-reveal="reveal-email" href="#"><i class="mail outline icon"></i> E-mail</a></li> -->
                                              <!-- <li><a title="Комментарии к купону" data-reveal="reveal-comments" href="#"><i class="comments outline icon"></i> 0 Комментарии</a></li> -->
                                          </ul>
                                          <div data-coupon-id="99" class="reveal-content reveal-share">
                                              <span class="close"></span>
                                              <h4>Поделиться с друзьями</h4>
                                              <div class="ui fluid left icon input">
                                                  <input value="[SITE]/yandex-market-promokod/99/" type="text">
                                                  <i class="linkify icon"></i>
                                              </div>
                                              <br>
                                              <div class="coupon-share">
                                              </div>
                                          </div>
                                          <div data-coupon-id="99" class="reveal-content reveal-email">
                                              <span class="close"></span>
                                              <h4 class="send-mail-heading">Отправить этот купон на email</h4>
                                              <div class="ui fluid action left icon input">
                                                  <input class="email_send_to" placeholder="Email адрес ..." type="text">
                                                  <i class="mail outline icon"></i>
                                                  <div class="email_send_btn ui button btn btn_primary">Отправить</div>
                                              </div><br>
                                              <p>Это не подписка на рассылку по e-mail. Ваш e-mail (или e-mail вашего друга) будет использован только для отправки этого купона.</p>
                                          </div>
                                          <div data-coupon-id="99" class="reveal-content reveal-comments">
                                              <span class="close"></span>
                                              <div data-id="99" class="comments-coupon-99 ui threaded comments">
                                                  <h4>Загрузка комментариев....</h4>
                                              </div>

                                              <h4>Пусть другие узнают, сколько вы сэкономили</h4>
                                              <form class="coupon-comment-form" data-cf="99" action="[SITE]/" method="post">

                                                  <div style="display: none;" class="ui success message">
                                                      Ваш комментарий отправлен. </div>

                                                  <div style="display: none;" class="ui negative message">
                                                      Что-то пошло не так! Пожалуйста, повторите попытку позже. </div>

                                                  <div class="ui form">
                                                      <div class="field comment_content">
                                                          <textarea class="comment_content" name="c_comment[comment_content]" placeholder="Добавить комментарий"></textarea>
                                                      </div>
                                                      <div class="two fields">
                                                          <div class="field comment_author">
                                                              <input type="text" class="comment_author" name="c_comment[comment_author]" placeholder="Ваше имя">
                                                          </div>
                                                          <div class="field comment_author_email">
                                                              <input type="text" class="comment_author_email" name="c_comment[comment_author_email]" placeholder="Ваш e-mail">
                                                          </div>
                                                      </div>
                                                      <button type="submit" class="ui button btn btn_primary">Отправить</button>
                                                  </div>
                                                  <input type="hidden" name="action" value="wpcoupon_coupon_ajax">
                                                  <input type="hidden" name="st_doing" value="new_comment">
                                                  <input type="hidden" name="_wpnonce" value="668ed1eb67821">
                                                  <input type="hidden" name="c_comment[comment_parent]" class="comment_parent">
                                                  <input type="hidden" name="c_comment[comment_post_ID]" value="99" class="comment_post_ID">
                                              </form>
                                          </div>
                                      </div>
                                      <!-- Coupon Modal -->
                                      <div data-modal-id="99" class="ui modal coupon-modal coupon-code-modal">
                                          <div class="scrolling content">
                                              <div class="coupon-header clearfix">
                                                  <div class="coupon-store-thumb">
                                                      <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_medium-thumb size-wpcoupon_medium-thumb" alt="" title="яндекс маркет" decoding="async" /> </div>
                                                  <div class="coupon-title" title="МегаРаспродажа и только свежие акции на МегаМаркет">МегаРаспродажа и только свежие акции на МегаМаркет</div>
                                                  <span class="close icon"></span>
                                              </div>
                                              <div class="coupon-content">
                                                  <p class="coupon-type-text">
                                                                                                        Скидка активирована, код купона не требуется!
                                                                                                      </p>
                                                  <div class="modal-code">
                                                                                                          <a class="ui button btn btn_secondary deal-actived" target="_blank" rel="nofollow" href="[SITE]/yandex-market-promokod/out/99">Товары в Категории<i class="angle right icon"></i></a>
                                                                                                      </div>
                                                  <div class="clearfix">
                                                      <!-- <div class="user-ratting ui icon basic buttons">
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="up" data-coupon-id="99" data-position="top center"  data-tooltip="Работает"><i class="smile outline icon"></i></div>
                                                          <div class="ui button icon-popup coupon-vote" data-vote-type="down" data-coupon-id="99" data-position="top center"  data-tooltip="Не работает"><i class="frown outline icon"></i></div>
                                                      </div> -->

                                                      
                                                  </div>
                                                  <div class="clearfixp">
                                                      <!-- <span class="user-ratting-text">Не работает?</span> -->
                                                      <span class="show-detail"><a href="#">Детали купона<i class="angle down icon"></i></a></span>
                                                  </div>
                                                  <div class="coupon-popup-detail">
                                                      <div class="coupon-detail-content">
                                                          <p>Подробности акции при переходе по ссылке.</p>
                                                      </div>
                                                      <p><strong>Истекает</strong>: Истекает 11.07.2025</p>
                                                      <!-- <p><strong>Отправлено</strong>: 2 дня назад </p> -->
                                                  </div>
                                              </div>
                                              <div class="coupon-footer">
                                                  <!-- <ul class="clearfix">
                                                      <li><span><i class="eye icon"></i> 100 использовано - 50 сегодня</span></li>
                                                  </ul> -->

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                                                    
                                     
                                </div>
                                <!-- END .store-listings -->
                                <!-- <div class="store-load-more wpb_content_element">
                                    <a href="[SITE]/yandex-market-promokod/page/2/" class="ui button btn btn_primary btn_large" id="load-more-btn" style="position: relative;" data-loading-text="Загрузка...">Загрузить другие купоны <i class="arrow alternate circle down outline icon"></i>
                                </a>
                                </div> -->
                            </div>
                            <!-- /.ajax-coupons -->
                        </section>

                        <div class="p-10">
                        </div>
                    </main>
                    <!-- #main -->
                </div>
				
                <!-- #primary -->

                <!--  Store Sidebar  Area-->
                <div id="secondary" class="widget-area sidebar store-sidebar" role="complementary">
                    <!--Store logo-->
                    <!-- <div class="inner shadow-box">
                        <div class="inner-content clearfix">
                            <div class="header-thumb">
                                <div class="header-store-thumb" style="box-shadow: 0 0 0;">
                                    <a rel="nofollow" target="_blank" title="Магазин Яндекс Маркет" href="https://market.yandex.ru/">
                                        <img width="200" height="115" src="[SITE]/promokod/img/yandeks-market-jpg.webp" class="attachment-wpcoupon_small_thumb size-wpcoupon_small_thumb" alt="Яндекс Маркет" title="яндекс маркет" decoding="async" loading="lazy" />                                        </a>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <!--  Store Description3  -->
                    <!-- <h4 class="store-about-title">О  Яндекс Маркет</h4> -->
                    <div class="inner shadow-box">
                        <div class="inner-content clearfix">
                            <div class="header-content">

                                <!-- <div class="bp-star-ratings  top-left lft" data-id="67">
                                    <div class="bpsr-stars bpsr-star gray">
                                        <div class="bpsr-fuel bpsr-star yellow" style="width:0%;"></div>
                                        <a href="#1"></a>
                                        <a href="#2"></a>
                                        <a href="#3"></a>
                                        <a href="#4"></a>
                                        <a href="#5"></a>
                                    </div>
                                    <div class="bpsr-legend"><span itemprop="ratingValue">4.7</span> / 5</div>
                                </div> -->
                                <!-- bp-star-ratings -->
                             <p>[MYCB(CHATGTP3DI)] </p>


                            </div>
                        </div>
                    </div>


                    <!-- <aside class="widget widget_store_cat_filter">
                        <h4 class="widget-title">Фильтр магазинов</h4>
                        <div class="shadow-box">
                            <div class="store-cat-filter-wrapper store-cat-filter ui list">
                                <h5>Категории</h5>
                                <div class="item">
                                    <label for="store-cat-filter-99">
								<input
									id="store-cat-filter-99"
									type="checkbox"
									class="wpcoupon-cat-filter-item store-filter-cat store-filter-cat-item"
									name="wpcoupon_cat_filter" value="%d0%bc%d0%b0%d1%80%d0%ba%d0%b5%d1%82%d0%bf%d0%bb%d0%b5%d0%b9%d1%81%d1%8b"
									 />
								<span class="cat-filter-name">Маркетплейсы</span>
							</label>
                                </div>
                            </div>
                            <input type="hidden" class="store_base_pagenum_url" name="store_base_pagenum_url" value="[SITE]/store/market_yandex_ru/797/" />
                            <input type="hidden" class="store_pagenum_url" name="store_pagenum_url" value="[SITE]/store/market_yandex_ru/797/" />
                            <input type="hidden" class="store_next_pagenum_url" name="store_next_pagenum_url" value="[SITE]/store/market_yandex_ru/797/page/2/" />

                            <div class="store-filter-sortby-wrapper ui list">
                                <h5>Сортировать по</h5>
                                <div class="item">
                                    <label for="store-sortby-newest">
						<input id="store-sortby-newest"  checked='checked' type="radio" class="store-filter-sortby sortby-newest store-filter-cat-item" name="store-filter-sortby" value="newest" />
						<span class="filter-sortby-name">Новые</span>
					</label>
                                </div>
                                <div class="item">
                                    <label for="store-sortby-popularity">
						<input id="store-sortby-popularity"  type="radio" class="store-filter-sortby sortby-popularity store-filter-cat-item" name="store-filter-sortby" value="popularity" />
						<span class="filter-sortby-name">Популярные</span>
					</label>
                                </div>
                                <div class="item">
                                    <label for="store-sortby-endingsoon">
						<input id="store-sortby-endingsoon"  type="radio" class="store-filter-sortby sortby-ending-soon store-filter-cat-item" name="store-filter-sortby" value="ending-soon" />
						<span class="filter-sortby-name">Скоро закончится</span>
					</label>
                                </div>
                                <div class="item">
                                    <label for="store-sortby-expired">
						<input id="store-sortby-expired"  type="radio" class="store-filter-sortby sortby-expired store-filter-cat-item" name="store-filter-sortby" value="expired" />
						<span class="filter-sortby-name">Истек</span>
					</label>
                                </div>
                            </div>
                        </div>
                    </aside> -->
                </div>
                <!-- #secondary -->

            </div>
            <!-- /#content-wrap -->

        </div>
        <!-- END .site-content -->

        <footer id="colophon" class="site-footer footer-widgets-on" role="contentinfo">
            <div class="container">
                <div class="footer_copy">
                    <div id="footer-nav" class="site-footer-nav">
                        <ul id="menu-footer-menu" class="menu">
                            <li id="menu-item-255" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-255"><a href="[SITE]/privacy-policy">Политика конфиденциальности</a></li>
                            <li id="menu-item-257" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-257"><a href="mailto:webmaster@[HOST].ru">Контакты</a></li>
                        </ul>
                    </div>
                    <div class="footer-cpy-text">
                        <div>{STAT-1}[RANDLINE-(iin.txt)]{/STAT}</div>
                        <div class="c-text"></div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- END #colophon-->
    </div>
    <!-- END #page -->
    <!-- wpu-modal -->
    <script type="text/javascript" src="/promokod/js/contactFormSeven.min.js?ver=1.2.0" id="wp-yandex-metrika_contact-form-7-js"></script>
    <script type="text/javascript" src="/promokod/js/index.js?ver=5.9" id="swv-js"></script>
    <script type="text/javascript" id="contact-form-7-js-extra">
        /* <![CDATA[ */
        var wpcf7 = {"api":{"root":"https:\/\/[HOST].ru\/promokod-json\/","namespace":"contact-form-7\/v1"}};
        /* ]]> */
    </script>
    <script type="text/javascript" src="/promokod/js/index2.js?ver=5.9" id="contact-form-7-js"></script>
    <script type="text/javascript" src="/promokod/js/libs.js?ver=1.1" id="wpcoupon_libs-js"></script>
    <script type="text/javascript" id="wpcoupon_global-js-extra">
    /* <![CDATA[ */
    var ST = {"ajax_url":"\/promokod-ajax","home_url":"https:\/\/[HOST].ru\/","enable_single":"0","auto_open_coupon_modal":"1","vote_expires":"7","_wpnonce":"7cecfc670f","_coupon_nonce":"4f67bac6ab","user_logedin":"","added_favorite":"\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435","add_favorite":"\u041b\u044e\u0431\u0438\u043c\u044b\u0439 \u043c\u0430\u0433\u0430\u0437\u0438\u043d","login_warning":"\u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430, \u0432\u043e\u0439\u0434\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c...","save_coupon":"\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u044d\u0442\u043e\u0442 \u043a\u0443\u043f\u043e\u043d","saved_coupon":"\u041a\u0443\u043f\u043e\u043d \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d","no_results":"\u041d\u0435\u0442 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u043e\u0432...","copied":"\u0421\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d\u043e","copy":"\u041a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u0442\u044c","print_prev_tab":"0","sale_prev_tab":"1","code_prev_tab":"1","coupon_click_action":"prev","share_id":"","header_sticky":"","my_saved_coupons":[""],"my_favorite_stores":[],"coupon_id":"67"};
    /* ]]> */
      jQuery("html, body").animate({
          scrollTop: jQuery("[data-id=67].coupon-item").offset().top
      }, 100);
          </script>
    <script type="text/javascript" src="/promokod/js/global.js?ver=1.1" id="wpcoupon_global-js"></script>
    <script type="text/javascript" id="wp-users-js-extra">
        /* <![CDATA[ */
        var WP_Users = {"ajax_url":"\/promokod-ajax","current_action":"","is_current_user":"","hide_txt":"Hide","show_txt":"Show","current_url":"\/store\/market_yandex_ru\/797\/","invalid_file_type":"This is not an allowed file type.","_wpnonce":"7cecfc670f","cover_text":"Cover image","avatar_text":"Avatar","remove_text":"Default","upload_text":"Upload Photo"};
        /* ]]> */
    </script>
    <script type="text/javascript" src="/promokod/js/user.js?ver=1.0" id="wp-users-js"></script>
</body>

</html>
